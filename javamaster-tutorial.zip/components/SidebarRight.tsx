import React from 'react';
import { ExternalLink, Award, FileText, Zap } from 'lucide-react';

const SidebarRight: React.FC = () => {
  return (
    <div className="sticky top-24 space-y-6">
      
      {/* Quick Links */}
      <div className="bg-white rounded shadow-sm border border-slate-200 p-5">
        <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2 text-h5">
          <Zap size={18} className="text-primary" /> Quick Links
        </h3>
        <ul className="space-y-3 text-body">
          <li>
            <a href="#" className="text-slate-600 hover:text-primary transition-colors flex items-center justify-between">
              Java Reference <ExternalLink size={12} />
            </a>
          </li>
          <li>
            <a href="#" className="text-slate-600 hover:text-primary transition-colors flex items-center justify-between">
              Java Exercises <ExternalLink size={12} />
            </a>
          </li>
          <li>
            <a href="#" className="text-slate-600 hover:text-primary transition-colors flex items-center justify-between">
              Download Java <ExternalLink size={12} />
            </a>
          </li>
        </ul>
      </div>

      {/* Ad Placeholder */}
      <div className="bg-white rounded p-6 text-center border-2 border-dashed border-slate-300 min-h-[250px] flex flex-col items-center justify-center">
        <span className="text-slate-400 font-bold text-small uppercase tracking-widest mb-2">Advertisement</span>
        <div className="text-slate-300 text-body">Space for Ad</div>
      </div>

      {/* Related Topics */}
      <div className="bg-white rounded shadow-sm border border-slate-200 p-5">
        <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2 text-h5">
          <FileText size={18} className="text-primary" /> Related Topics
        </h3>
        <div className="flex flex-wrap gap-2">
          {['C++', 'C#', 'Python', 'JavaScript'].map(lang => (
            <span key={lang} className="px-3 py-1 bg-slate-100 text-slate-600 text-small rounded hover:bg-slate-200 cursor-pointer transition-colors">
              {lang}
            </span>
          ))}
        </div>
      </div>

      {/* Certificate CTA */}
      <div className="bg-primary rounded shadow-md p-5 text-center text-white relative overflow-hidden group">
        <div className="absolute top-0 right-0 -mr-8 -mt-8 w-24 h-24 bg-white opacity-10 rounded-full group-hover:scale-150 transition-transform duration-500"></div>
        <Award size={40} className="mx-auto mb-3 text-white" />
        <h3 className="font-bold text-h4 mb-2">Get Certified</h3>
        <p className="text-body opacity-90 mb-4 text-blue-50">Prove your knowledge with our official Java certification.</p>
        <button className="w-full bg-white hover:bg-slate-50 text-primary text-btn font-bold py-2.5 rounded shadow-sm transition-all">
          View Certificate
        </button>
      </div>

    </div>
  );
};

export default SidebarRight;