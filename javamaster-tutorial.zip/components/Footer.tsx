import React from 'react';
import { Facebook, Twitter, Instagram, Linkedin, Mail, MapPin } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-dark text-slate-300 pt-16 pb-8">
      <div className="max-w-[1600px] mx-auto px-6">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          
          {/* Company Info */}
          <div>
            <h3 className="text-white font-bold text-h3 mb-6">Java<span className="text-primary">Master</span></h3>
            <p className="text-body leading-relaxed mb-6 text-slate-400">
              The world's largest web developer site. We create simplified and interactive learning experiences.
            </p>
            <div className="flex gap-4">
              <a href="#" className="hover:text-primary transition-colors"><Facebook size={20} /></a>
              <a href="#" className="hover:text-primary transition-colors"><Twitter size={20} /></a>
              <a href="#" className="hover:text-primary transition-colors"><Instagram size={20} /></a>
              <a href="#" className="hover:text-primary transition-colors"><Linkedin size={20} /></a>
            </div>
          </div>

          {/* Top Courses */}
          <div>
            <h4 className="text-white font-bold mb-6 text-h5">Top Tutorials</h4>
            <ul className="space-y-3 text-body">
              <li><a href="#" className="hover:text-white transition-colors">HTML Tutorial</a></li>
              <li><a href="#" className="hover:text-white transition-colors">CSS Tutorial</a></li>
              <li><a href="#" className="hover:text-white transition-colors">JavaScript Tutorial</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Java Tutorial</a></li>
              <li><a href="#" className="hover:text-white transition-colors">SQL Tutorial</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-bold mb-6 text-h5">Contact Us</h4>
            <ul className="space-y-4 text-body">
              <li className="flex items-start gap-3">
                <MapPin size={18} className="text-primary mt-0.5" />
                <span>123 Tech Avenue,<br />Silicon Valley, CA 94000</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail size={18} className="text-primary" />
                <span>learn@javamaster.com</span>
              </li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="text-white font-bold mb-6 text-h5">Stay Updated</h4>
            <p className="text-small mb-4 text-slate-400">Join our newsletter for the latest updates and tutorials.</p>
            <div className="flex flex-col gap-2">
              <input 
                type="email" 
                placeholder="Enter email address" 
                className="bg-white/5 border border-white/10 rounded px-4 py-2 text-body focus:outline-none focus:border-primary text-white"
              />
              <button className="bg-primary hover:bg-primary-hover text-white text-btn font-bold py-2 rounded transition-colors">
                Subscribe
              </button>
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-small text-slate-500">
          <p>© 2023 JavaMaster. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-white transition-colors">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;