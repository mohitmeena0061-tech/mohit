import React, { useState } from 'react';
import { Copy, Check } from 'lucide-react';

interface CodeBlockProps {
  code: string;
  title?: string;
}

const CodeBlock: React.FC<CodeBlockProps> = ({ code, title = "Example" }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Simple pseudo-syntax highlighting for Java
  const highlightCode = (text: string) => {
    const keywords = ['public', 'class', 'static', 'void', 'main', 'String'];
    const methods = ['println', 'print', 'out', 'System'];
    
    // Split by lines to easier handle comments or just process crudely for demo
    // This is a visual simulation, not a full parser
    return text.split('\n').map((line, i) => (
      <div key={i} className="table-row">
        <span className="table-cell text-slate-500 text-right pr-4 select-none w-8 text-small">{i + 1}</span>
        <span className="table-cell">
            {line.split(/(".*?"|[^"\s]+|\s+)/).map((token, j) => {
                if (token.startsWith('"')) return <span key={j} className="text-green-400">{token}</span>;
                if (keywords.includes(token)) return <span key={j} className="text-blue-400 font-medium">{token}</span>;
                if (methods.includes(token.replace('.', ''))) return <span key={j} className="text-yellow-200">{token}</span>; // Simplistic
                if (token.trim().startsWith('//')) return <span key={j} className="text-slate-500 italic">{token}</span>;
                return <span key={j} className="text-slate-300">{token}</span>;
            })}
        </span>
      </div>
    ));
  };

  return (
    <div className="my-6 rounded overflow-hidden shadow-md border border-slate-200 bg-[#1e1e1e]">
      <div className="flex items-center justify-between px-4 py-2 bg-[#2d2d2d] border-b border-[#404040]">
        <span className="text-small font-bold text-slate-400 uppercase tracking-wider">{title}</span>
        <button 
          onClick={handleCopy}
          className="flex items-center gap-1.5 text-small text-slate-400 hover:text-white transition-colors"
        >
          {copied ? <Check size={14} className="text-green-400" /> : <Copy size={14} />}
          {copied ? 'Copied!' : 'Copy Code'}
        </button>
      </div>
      <div className="p-4 overflow-x-auto font-mono text-body leading-relaxed">
        <div className="table w-full">
            {highlightCode(code)}
        </div>
      </div>
      <div className="px-4 py-3 bg-[#252526] border-t border-[#404040] flex justify-end">
        <button className="bg-primary hover:bg-primary-hover text-white text-btn font-medium px-6 py-2 rounded transition-all shadow-sm transform hover:-translate-y-0.5 active:translate-y-0">
          Try it Yourself »
        </button>
      </div>
    </div>
  );
};

export default CodeBlock;