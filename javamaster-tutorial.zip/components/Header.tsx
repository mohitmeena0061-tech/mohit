import React from 'react';
import { Menu, Search, Sun, BookOpen, User } from 'lucide-react';

interface HeaderProps {
  toggleMobileMenu: () => void;
}

const Header: React.FC<HeaderProps> = ({ toggleMobileMenu }) => {
  return (
    <header className="bg-white shadow-sm sticky top-0 z-50 border-b border-slate-200">
      <div className="max-w-[1600px] mx-auto px-4 h-16 flex items-center justify-between">
        
        {/* Logo & Mobile Menu */}
        <div className="flex items-center gap-4">
          <button 
            onClick={toggleMobileMenu}
            className="md:hidden p-1 hover:bg-slate-100 rounded transition-colors text-slate-700"
          >
            <Menu size={24} />
          </button>
          
          <a href="#" className="flex items-center gap-2 group">
            <div className="bg-primary p-1.5 rounded group-hover:rotate-12 transition-transform duration-300">
              <BookOpen size={24} className="text-white" />
            </div>
            <span className="text-h3 font-bold text-slate-800 tracking-tight">
              Java<span className="text-primary">Master</span>
            </span>
          </a>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-1">
          {['Home', 'Courses', 'Tutorials', 'Exercises', 'Certificates'].map((item) => (
            <a 
              key={item} 
              href="#" 
              className="px-4 py-2 hover:bg-primary/10 hover:text-primary rounded text-body font-medium text-slate-600 transition-all"
            >
              {item}
            </a>
          ))}
        </nav>

        {/* Actions */}
        <div className="flex items-center gap-3">
          <div className="relative hidden lg:block">
            <input 
              type="text" 
              placeholder="Search..." 
              className="bg-slate-100 border border-slate-200 rounded py-1.5 pl-4 pr-10 text-body focus:outline-none focus:bg-white focus:border-primary focus:text-slate-800 placeholder-slate-400 transition-all w-48 focus:w-64"
            />
            <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
          </div>
          
          <button className="p-2 hover:bg-slate-100 rounded text-slate-600 transition-colors hidden sm:block">
            <Sun size={20} />
          </button>
          
          <button className="bg-primary hover:bg-primary-hover text-white px-5 py-1.5 rounded text-btn font-medium transition-colors shadow-sm flex items-center gap-2">
            Log in <User size={16} />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;