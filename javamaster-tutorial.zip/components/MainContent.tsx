import React from 'react';
import CodeBlock from './CodeBlock';
import { ChevronRight, CheckCircle2, AlertTriangle, Lightbulb } from 'lucide-react';

const MainContent: React.FC = () => {
  return (
    <div className="p-6 lg:p-10 max-w-4xl mx-auto">
      {/* Breadcrumbs */}
      <nav className="flex items-center text-small text-slate-500 mb-6 overflow-x-auto whitespace-nowrap">
        <a href="#" className="hover:text-primary transition-colors">Java Tutorial</a>
        <ChevronRight size={14} className="mx-2" />
        <span className="font-medium text-slate-800">Java Output</span>
      </nav>

      {/* Page Title */}
      <h1 className="text-h1 font-bold text-slate-800 mb-6">Java Output / Print</h1>

      <div className="flex items-center gap-2 mb-8">
        <button className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-4 py-2 rounded text-body font-medium transition-colors">
          « Previous
        </button>
        <button className="bg-primary hover:bg-primary-hover text-white px-6 py-2 rounded text-body font-medium transition-colors shadow-sm flex-1 md:flex-none text-center">
          Next »
        </button>
      </div>

      {/* Intro Text */}
      <p className="text-body text-slate-600 mb-8 leading-relaxed">
        Output is a critical part of any programming language. In Java, you can display text and variables to the console using specific methods provided by the System class.
      </p>

      <hr className="border-slate-200 mb-10" />

      {/* Section 1: Print Text */}
      <section id="print-text" className="mb-12">
        <h2 className="text-mob-h2 md:text-h2 font-bold text-slate-800 mb-4 flex items-center gap-2">
          Print Text
        </h2>
        <div className="h-1 w-12 bg-primary rounded mt-1 mb-4"></div>
        
        <p className="text-mob-body md:text-body text-slate-600 mb-4">
          You learned from the previous chapter that you can use the <code className="bg-red-50 text-red-600 px-1.5 py-0.5 rounded font-mono text-small">println()</code> method to output values or print text in Java:
        </p>
        
        <CodeBlock 
          title="Example: Printing Text"
          code={`public class Main {
  public static void main(String[] args) {
    System.out.println("Hello World!");
    System.out.println("I am learning Java.");
    System.out.println("It is awesome!");
  }
}`}
        />

        <div className="bg-blue-50 border-l-4 border-primary p-4 rounded-r my-6">
          <div className="flex items-start gap-3">
            <Lightbulb className="text-primary flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-bold text-slate-800 text-body mb-1">Did you know?</h4>
              <p className="text-mob-body md:text-body text-slate-600">
                You can add as many <code className="font-mono text-primary font-bold">println()</code> methods as you want. Each method call will output the text on a new line.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Section 2: Double Quotes */}
      <section id="double-quotes" className="mb-12">
        <h2 className="text-mob-h2 md:text-h2 font-bold text-slate-800 mb-4">Double Quotes</h2>
        <p className="text-mob-body md:text-body text-slate-600 mb-4">
          When you are working with text (strings), it must be wrapped inside double quotation marks <code className="bg-slate-100 px-1 rounded font-mono text-small">""</code>.
        </p>
        <p className="text-mob-body md:text-body text-slate-600 mb-4">
          If you forget the double quotes, an error occurs:
        </p>

        <div className="grid md:grid-cols-2 gap-6 mb-6">
           <div className="bg-white border border-green-200 rounded p-5 shadow-sm">
             <div className="flex items-center gap-2 mb-3 text-green-700 font-bold text-body">
               <CheckCircle2 size={20} /> Correct
             </div>
             <code className="block bg-slate-50 p-3 rounded border border-green-100 font-mono text-small text-slate-700">
               System.out.println("Hello World!");
             </code>
           </div>
           
           <div className="bg-white border border-red-200 rounded p-5 shadow-sm">
             <div className="flex items-center gap-2 mb-3 text-red-700 font-bold text-body">
               <AlertTriangle size={20} /> Incorrect
             </div>
             <code className="block bg-slate-50 p-3 rounded border border-red-100 font-mono text-small text-slate-700">
               System.out.println(Hello World!);
             </code>
           </div>
        </div>
      </section>

      {/* Section 3: The print() Method */}
      <section id="print-method" className="mb-12">
        <h2 className="text-mob-h2 md:text-h2 font-bold text-slate-800 mb-4">The Print() Method</h2>
        <p className="text-mob-body md:text-body text-slate-600 mb-4">
          There is also a <code className="bg-red-50 text-red-600 px-1.5 py-0.5 rounded font-mono text-small">print()</code> method, which is similar to <code className="bg-red-50 text-red-600 px-1.5 py-0.5 rounded font-mono text-small">println()</code>.
        </p>
        <p className="text-mob-body md:text-body text-slate-600 mb-4">
          The only difference is that it does not insert a new line at the end of the output:
        </p>

        <CodeBlock 
          title="Example: print() vs println()"
          code={`public class Main {
  public static void main(String[] args) {
    System.out.print("Hello World! ");
    System.out.print("I will print on the same line.");
  }
}`}
        />
        
        <p className="text-small text-slate-500 italic mt-2">
          Note that we added an extra space (after "Hello World!") for better readability in the example above.
        </p>
      </section>

      <div className="flex items-center gap-2 mt-10 pb-10">
        <button className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-4 py-2 rounded text-body font-medium transition-colors">
          « Previous
        </button>
        <button className="bg-primary hover:bg-primary-hover text-white px-6 py-2 rounded text-body font-medium transition-colors shadow-sm flex-1 md:flex-none text-center">
          Next »
        </button>
      </div>

    </div>
  );
};

export default MainContent;