import React from 'react';
import { ChevronRight, Home } from 'lucide-react';

const topics = [
  { title: 'Java HOME', active: false, icon: Home },
  { title: 'Java Intro', active: false },
  { title: 'Java Get Started', active: false },
  { title: 'Java Syntax', active: false },
  { title: 'Java Output', active: true },
  { title: 'Java Comments', active: false },
  { title: 'Java Variables', active: false },
  { title: 'Java Data Types', active: false },
  { title: 'Java Type Casting', active: false },
  { title: 'Java Operators', active: false },
  { title: 'Java Strings', active: false },
  { title: 'Java Math', active: false },
  { title: 'Java Booleans', active: false },
  { title: 'Java If...Else', active: false },
  { title: 'Java Switch', active: false },
  { title: 'Java While Loop', active: false },
  { title: 'Java For Loop', active: false },
  { title: 'Java Break/Continue', active: false },
  { title: 'Java Arrays', active: false },
];

const SidebarLeft: React.FC = () => {
  return (
    <div className="h-full overflow-y-auto custom-scrollbar bg-white rounded pb-20 border border-slate-100 md:border-none">
      <div className="p-4">
        <h3 className="text-small font-bold text-slate-400 uppercase tracking-wider mb-4">Tutorial Index</h3>
        <div className="space-y-1">
          {topics.map((topic, index) => (
            <a
              key={index}
              href="#"
              className={`
                flex items-center justify-between px-4 py-2.5 rounded text-body transition-all duration-200
                ${topic.active 
                  ? 'bg-primary text-white font-medium shadow-sm' 
                  : 'text-slate-600 hover:bg-slate-50 hover:text-primary'}
              `}
            >
              <div className="flex items-center gap-3">
                {topic.icon && <topic.icon size={16} />}
                {topic.title}
              </div>
              {!topic.active && <ChevronRight size={14} className="text-slate-400" />}
            </a>
          ))}
        </div>
      </div>
      
      {/* Promo Box in Sidebar */}
      <div className="px-4 mt-6">
        <div className="bg-gradient-to-br from-primary to-primary-hover rounded p-4 text-white shadow-md">
          <h4 className="font-bold text-h4 mb-2">Get Certified</h4>
          <p className="text-small opacity-90 mb-3">Complete the course and get your official Java certificate.</p>
          <button className="w-full bg-white text-primary text-small font-bold py-2 rounded hover:bg-slate-50 transition-colors">
            Start Now
          </button>
        </div>
      </div>
    </div>
  );
};

export default SidebarLeft;