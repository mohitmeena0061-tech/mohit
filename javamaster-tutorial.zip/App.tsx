import React, { useState } from 'react';
import Header from './components/Header';
import SidebarLeft from './components/SidebarLeft';
import SidebarRight from './components/SidebarRight';
import MainContent from './components/MainContent';
import Footer from './components/Footer';

export default function App() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <div className="min-h-screen flex flex-col bg-page font-sans">
      <Header toggleMobileMenu={toggleMobileMenu} />
      
      <div className="flex-1 max-w-[1600px] w-full mx-auto flex flex-col md:flex-row relative pt-6 gap-6 px-4">
        {/* Left Sidebar - Navigation */}
        <aside 
          className={`
            fixed inset-y-0 left-0 z-40 w-64 bg-white shadow-xl transform transition-transform duration-300 ease-in-out
            md:relative md:translate-x-0 md:shadow-none md:w-64 lg:w-72 flex-shrink-0 rounded
            ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}
          `}
        >
          <SidebarLeft />
        </aside>

        {/* Overlay for mobile menu */}
        {isMobileMenuOpen && (
          <div 
            className="fixed inset-0 bg-black bg-opacity-50 z-30 md:hidden"
            onClick={() => setIsMobileMenuOpen(false)}
          />
        )}

        {/* Main Content Area */}
        <main className="flex-1 min-w-0 bg-white shadow-sm rounded">
          <MainContent />
        </main>

        {/* Right Sidebar - Desktop Only */}
        <aside className="hidden xl:block w-72 flex-shrink-0">
          <SidebarRight />
        </aside>
      </div>

      <div className="mt-12">
        <Footer />
      </div>
    </div>
  );
}